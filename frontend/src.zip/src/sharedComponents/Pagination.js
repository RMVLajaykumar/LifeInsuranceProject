import React from 'react';
import { Pagination as BootstrapPagination } from 'react-bootstrap';

const Pagination = ({ noOfPages, currentPage, setPageNo }) => {
  const pageItems = [];

  const handlePageChange = (page) => {
    if (page > 0 && page <= noOfPages) {
      setPageNo(page);
    }
  };

  for (let number = 1; number <= noOfPages; number++) {
    pageItems.push(
      <BootstrapPagination.Item
        key={number}
        active={number === currentPage}
        onClick={() => handlePageChange(number)}
      >
        {number}
      </BootstrapPagination.Item>
    );
  }

  return (
    <BootstrapPagination className="justify-content-center mt-4">
      <BootstrapPagination.First onClick={() => handlePageChange(1)} />
      <BootstrapPagination.Prev onClick={() => handlePageChange(currentPage - 1)} />
      {pageItems}
      <BootstrapPagination.Next onClick={() => handlePageChange(currentPage + 1)} />
      <BootstrapPagination.Last onClick={() => handlePageChange(noOfPages)} />
    </BootstrapPagination>
  );
};

export default Pagination;
