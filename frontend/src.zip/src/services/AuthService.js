import axios from 'axios';
import {UnAuthorized, InvalidCredentialError, InternalServerError} from '../utils/errors/Error';


export const verifyAdmin = async (headers = {}) => {
    if(!localStorage.getItem('token')){
        throw new UnAuthorized("User is not logged in");
    }
    const token = localStorage.getItem('token');
    try {
        const response = await axios.get(`http://localhost:8081/SecureLife.com/verify/admin`, {
            headers: {
                Authorization: `Bearer ${token}`,
                ...headers
            }
        });
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const verifyCustomer = async (headers = {}) => {
    if(!localStorage.getItem('token')){
        throw new UnAuthorized("User is not logged in");
    }
    const token = localStorage.getItem('token');
    try {
        const response = await axios.get(`http://localhost:8081/SecureLife.com/verify/customer`, {
            headers: {
                Authorization: `Bearer ${token}`,
                ...headers
            }
        });
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const verifyEmployee = async (headers = {}) => {
    if (!localStorage.getItem('token')) {
      throw new UnAuthorized("User is not logged in");
    }
    
    const token = localStorage.getItem('token');
    
    try {
      const response = await axios.get(`http://localhost:8081/SecureLife.com/verify/employee`, {
        headers: {
          Authorization: `Bearer ${token}`,
          ...headers
        }
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  export const verifyAgent = async (headers = {}) => {
    if (!localStorage.getItem('token')) {
      throw new UnAuthorized("User is not logged in");
    }
    
    const token = localStorage.getItem('token');
    
    try {
      const response = await axios.get(`http://localhost:8081/SecureLife.com/verify/agent`, {
        headers: {
          Authorization: `Bearer ${token}`,
          ...headers
        }
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  
  
  // export const getProfileName = async () => {
  //   const token = localStorage.getItem('token');
    
  //   if (!token) {
  //     throw new Error("User is not logged in");
  //   }
    
  //   try {
  //     const response = await axios.get(`http://localhost:8081/SecureLife.com/profile`, {
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //         'Content-Type': 'application/json'
  //       }
  //     });
      
  //     const profileData = response.data;
  //     console.log("Profile Data:", profileData);
  
     
  //     return profileData.name;
  //   } catch (error) {
  //     console.error("Error fetching profile:", error);
  //     throw error;
  //   }
  // };
  


export const loginService = async (usernameOrEmail, password) => {
    try {
      const response = await axios.post(`http://localhost:8081/SecureLife.com/login`, { usernameOrEmail, password }, {
        headers: { 'Content-Type': 'application/json' }
      });
      const token = response.headers['authorization'];

    if (token) {
      localStorage.setItem('token', token);
    }
    console.log(response.data)
      return response.data;
    } catch (error) {
        if(error.response && error.response.status === 400){
            throw new InvalidCredentialError("Invalid Credentials");
        }else if(error.response && error.response.status === 401){
            throw new InternalServerError("Internal Server Error");
        }
    }
  };


  

  export const getProfile = async () => {
    if(!localStorage.getItem('token')){
        throw new UnAuthorized("User is not logged in");
    }
    const token = localStorage.getItem('token');
    try {
        const response = await axios.get(`http://localhost:8081/SecureLife.com/profile/view`, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        return response.data;
    } catch (error) {
        if (error.response && error.response.status === 403) {
            throw new UnAuthorized("User is unauthorized");
        }
        throw error;
    }
};



  export const setUser = async (userData) => {
    if(!localStorage.getItem('token')){
        throw new UnAuthorized("User is not logged in");
    }
    const token = localStorage.getItem('token');
    try {
        const response = await axios.put(`http://localhost:8081/api/auth/profile`, 
            userData, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error updating user profile:', error);
        throw error;
    }
};