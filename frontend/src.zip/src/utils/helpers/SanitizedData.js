const sanitizeData = (data) => {
    const result = [];

    const flattenObject = (obj, prefix = '') => {
        return Object.keys(obj).reduce((acc, key) => {
            const newKey = prefix ? `${prefix}_${key}` : key;
            
            // Handle arrays
            if (Array.isArray(obj[key])) {
                obj[key].forEach((item, index) => {
                    acc = { ...acc, ...flattenObject(item, `${newKey}_${index}`) };
                });
            } 
            // Handle nested objects
            else if (typeof obj[key] === 'object' && obj[key] !== null) {
                acc = { ...acc, ...flattenObject(obj[key], newKey) };
            } 
            // Handle primitive values, nulls, and undefined
            else {
                acc[newKey] = formatValue(obj[key]);
            }
            return acc;
        }, {});
    };

    // Format values to be more user-friendly
    const formatValue = (value) => {
        if (value === null || value === undefined) {
            return 'N/A';  // Handle null or undefined values
        }
        if (typeof value === 'string' && value.length > 100) {
            return value.substring(0, 100) + '...';  // Truncate long strings
        }
        if (isDate(value)) {
            return new Date(value).toLocaleDateString();  // Format date strings
        }
        return value;  // Return the value as-is if none of the above conditions apply
    };

    // Utility to check if a value is a valid date
    const isDate = (value) => {
        return !isNaN(Date.parse(value));
    };

    data.forEach(item => {
        result.push(flattenObject(item));
    });

    return result;
};

export default sanitizeData;
