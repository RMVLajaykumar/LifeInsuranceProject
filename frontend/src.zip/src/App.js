import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect, useState } from 'react';
import { Routes, Route, useNavigate, BrowserRouter } from 'react-router-dom';
import { getProfile } from './services/AuthService';
import Login from './components/Login';
import AdminDashboard from './components/adminPages/AdminDashboard';
import CustomerDashboard from './components/customerPages/CustomerDashboard';
import AgentDashboard from './components/agentPages/AgentDashboard';
import EmployeeDashboard from './components/employeePages/EmployeeDashboard';
import RequestOtp from './components/RequestOtp';
import VerifyOtp from './components/VerifyOtp';
import ResetPassword from './components/ResetPassword';
import AddAgent from './components/employeePages/AddAgent';
import UpdateAgentForm from'./components/employeePages/UpdateAgentForm';
import CustomerDoc from'./components/employeePages/CustomerDocuments';
import CustomerUpdateForm from './components/employeePages/CustomerUpdateForm';

import Loader from './sharedComponents/Loader';
import ViewAgentsTable from './components/employeePages/ViewAgents';
import ViewCustomers from './components/employeePages/ViewCustomers';
import ViewQueries from './components/customerPages/ViewQueries';
import ViewQueriesForEmployee from './components/employeePages/ViewQueriesForEmployee';
import ViewPolicyTable from './components/customerPages/ViewPolicies';
import ViewInstallmentTable from './components/customerPages/ViewInstallments';

const AuthRedirect = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuthAndRedirect = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const profile = await getProfile(token);
          const role = profile.role;

          switch (role) {
            case 'ROLE_ADMIN':
              navigate('/admin-dashboard');
              break;
            case 'ROLE_CUSTOMER':
              navigate('/customer-dashboard');
              break;
            case 'ROLE_EMPLOYEE':
              navigate('/employee-dashboard');
              break;
            case 'ROLE_AGENT':
              navigate('/agent-dashboard');
              break;
            default:
              navigate('/login');
              break;
          }
        } catch (error) {
          console.error('Failed to get profile:', error);
          navigate('/login');
        }
      } else {
        navigate('/login');
      }
      setLoading(false);
    };

    checkAuthAndRedirect();
  }, [navigate]);

  return loading ? <Loader /> : <Login />;
};

const App = () => {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/login' element={<Login />} />
        <Route path='/' element={<AuthRedirect />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/customer-dashboard" element={<CustomerDashboard />}/>
        <Route path="/agent-dashboard" element={<AgentDashboard />}/>
        <Route path="/employee-dashboard" element={<EmployeeDashboard />}/>
        <Route path="/forget-password" element={<RequestOtp />} />
        <Route path="/verify-otp" element={<VerifyOtp />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/employee-dashboard" element={<EmployeeDashboard/>}/>
        <Route path="/add-agent" element={<AddAgent/>}/>
        <Route path="/view-agents" element={<ViewAgentsTable/>}/>
        <Route path="/update-agent/:agentId" element={<UpdateAgentForm />} />
        <Route path="/view-customers" element={<ViewCustomers />} />
        <Route path="/customer/:customerId/documents" element={<CustomerDoc/>}/>
        <Route path="/customer/:customerId/edit" element={<CustomerUpdateForm/>} />
        <Route path="/view-queries" element={<ViewQueries/>} />
        <Route path="/view-queries/employee" element={<ViewQueriesForEmployee/>} />
        <Route path="/view-policy" element={<ViewPolicyTable/>} />
        <Route path="/policies/:policyId/installments" element={<ViewInstallmentTable/>} />
      </Routes>
      </BrowserRouter>
  );
};

export default App;