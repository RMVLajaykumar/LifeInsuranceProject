import React from 'react'

const AgentDashboard = () => {
  return (
    <div>AgentDashboard</div>
  )
}

export default AgentDashboard