import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Container, Row, Col, Form, Button, Card } from 'react-bootstrap';

import { loginService } from '../services/AuthService';

import { successToast, errorToast } from '../sharedComponents/MyToast';
import { ToastContainer } from 'react-toastify';
import Header from './layout/Header';
import Footer from './layout/Footer';




const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const data = await loginService(email, password);
      if (data.role === 'ROLE_ADMIN') {
        successToast('Logged in successfully!');
        navigate('/admin-dashboard');
      } 
      else if (data.role === 'ROLE_CUSTOMER') {
        successToast('Logged in successfully!');
        navigate('/customer-dashboard');
      } else if (data.role === 'ROLE_AGENT') {
        successToast('Logged in successfully!');
        navigate('/agent-dashboard');
      } 
      else if (data.role === 'ROLE_EMPLOYEE') {
        successToast('Logged in successfully!');
        navigate('/employee-dashboard');
      }
      else{
        errorToast("Redirecting issue")
      }
    } catch(error){
      errorToast(error.specificMessage)
    }
  };

  return (
    <Container fluid className="d-flex flex-column min-vh-100">
      <Header/>
      <Container fluid>
      <Row className="justify-content-center">
        
        <Col md={6} className="d-flex align-items-center justify-content-center bg-light p-5">
          <div className="text-center">
            <h1 className="display-4">SecureLife</h1>
            <p className="lead">Your trusted partner for securing your future.</p>
            {/* Add logo or other content here */}
          </div>
        </Col>

        <Col md={6} className="d-flex align-items-center justify-content-center bg-light">
        <Card className="p-4 shadow-lg m-5">
            <Card.Body>
              <h3 className="text-center mb-4 text-primary">Login</h3>
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="email">
                  <Form.Label>Username</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter your Username"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-4" controlId="password">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </Form.Group>

                <div className="d-flex justify-content-between mb-3">
                  <Link to="/forget-password" className="text-primary text-decoration-none">
                    Forgot Password?
                  </Link>
                  <Link to="/register-customer" className="text-primary text-decoration-none">
                    Register here
                  </Link>
                </div>

                <Button type="submit" variant="primary" className="w-100">
                  Login
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
      </Container>
      <ToastContainer />
      <Footer/>
    </Container>
  );
};

export default Login;