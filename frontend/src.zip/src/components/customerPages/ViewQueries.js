import React, { useState, useEffect } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { getAllQueries } from '../../services/CustomerService';

import Loader from '../../sharedComponents/Loader';
import NewToast, { showToast } from '../../sharedComponents/NewToast';
import BackButton from '../../sharedComponents/BackButton';
import Header from '../layout/Header';
import Footer from '../layout/Footer';

const ViewQueries = () => {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [size] = useState(5); 
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    fetchQueries();
  }, [page]);

  const fetchQueries = async () => {
    try {
      setLoading(true);
      const response = await getAllQueries(page, size);
      setQueries(response.content);
      setTotalPages(response.totalPages);
      setLoading(false);
    } catch (error) {
      showToast('Failed to load queries', 'error');
      setLoading(false);
    }
  };

  const handleNextPage = () => {
    if (page < totalPages - 1) setPage(page + 1);
  };

  const handlePreviousPage = () => {
    if (page > 0) setPage(page - 1);
  };

  if (loading) {
    return <Loader />;
  }

  return (
    <Container fluid className="mt-5 d-flex flex-column">
        <Header/>
        
      <Row className="py-5">
        <Col xs={12}>
          <h2>All Customer Queries</h2>
          {queries.length === 0 ? (
            <p>No queries available.</p>
          ) : (
            queries.map((query) => (
              <div key={query.queryId} className="query-item my-3 p-3" style={{ border: '1px solid #ccc', borderRadius: '5px' }}>
                <p>
                  <strong>Query ID:</strong> {query.queryId}
                </p>
                <p>
                  <strong>Customer ID:</strong> {query.customerId}
                </p>
                <p>
                  <strong>Question:</strong> {query.message}
                </p>
                <p>
                  <strong>Answer:</strong> {query.response ? query.response : 'No response yet'} {query.employeeId && ` (Employee ID: ${query.employeeId})`}
                </p>
              </div>
            ))
          )}
          <div className="pagination-controls mt-4">
            <button onClick={handlePreviousPage} disabled={page === 0} className="btn btn-primary mx-2">
              Previous
            </button>
            <button onClick={handleNextPage} disabled={page === totalPages - 1} className="btn btn-primary mx-2">
              Next
            </button>
          </div>
        </Col>
      </Row>
      
      <Footer/>
    </Container>
    
  );
};

export default ViewQueries;
