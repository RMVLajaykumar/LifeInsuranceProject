import React, { useEffect, useState } from 'react';
import { Modal, Button, Spinner } from 'react-bootstrap';
import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';
import { calculateTotalPaymentAmount, processPayment } from '../../services/CustomerService';
import { errorToast, successToast } from '../../sharedComponents/MyToast';

const PaymentModal = ({ show, handleClose, installmentAmount, policyId }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [totalAmount, setTotalAmount] = useState(null); // Holds the total amount with tax
  const [loading, setLoading] = useState(false); // Manages loading state for the payment
  const [isFetchingTotal, setIsFetchingTotal] = useState(true); // State for tracking if total amount is being fetched

  // Fetch total amount including tax
  useEffect(() => {
    const fetchTotalAmount = async () => {
      if (!installmentAmount) return; // Ensure there's an installment amount to calculate

      try {
        setIsFetchingTotal(true); // Start spinner while fetching total amount
        console.log('Fetching total amount for installment:', installmentAmount);

        const total = await calculateTotalPaymentAmount(installmentAmount);
        console.log('Total amount received from API:', total);
        
        setTotalAmount(total); // Update the state with the calculated total amount
      } catch (error) {
        console.error('Error fetching total amount:', error);
        errorToast('Failed to calculate total amount.');
        setTotalAmount('Error');
      } finally {
        setIsFetchingTotal(false); // Stop loading once the total is fetched
      }
    };

    fetchTotalAmount(); // Fetch total when the modal opens
  }, [installmentAmount]);

  // Handle Payment
  const handlePayment = async () => {
    if (!stripe || !elements || totalAmount === null) return; // Ensure Stripe is loaded and the amount is fetched

    setLoading(true); // Show spinner during payment process
    const cardElement = elements.getElement(CardElement);
    const { error, token } = await stripe.createToken(cardElement); // Get Stripe token for payment

    if (error) {
      console.error('Stripe error:', error);
      errorToast('Payment failed, please try again.');
      setLoading(false);
      return;
    }

    try {
      const paymentRequestDto = {
        policyAccountId: policyId,
        amount: totalAmount, // Use the fetched total amount
        stripeToken: token.id, // Send Stripe token
      };

      const response = await processPayment(paymentRequestDto); // Process the payment in the backend
      successToast('Payment succeeded!');
      handleClose(); // Close modal on success
    } catch (paymentError) {
      console.error('Payment error:', paymentError);
      errorToast('Payment failed, please try again.');
    } finally {
      setLoading(false); // Stop spinner after the payment attempt
    }
  };

  return (
    <Modal show={show} onHide={handleClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Payment</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>Paying for installment of amount including tax:</p>
        {isFetchingTotal ? (
          <Spinner animation="border" /> // Show spinner while fetching total amount
        ) : totalAmount === 'Error' ? (
          <p>Error calculating total amount</p>
        ) : (
          <p><strong>{totalAmount}</strong> INR</p> // Display the fetched total amount
        )}
        <div>
          <label>Card Details</label>
          <CardElement /> {/* Stripe's card element */}
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Cancel
        </Button>
        <Button
          variant="primary"
          onClick={handlePayment}
          disabled={loading || isFetchingTotal || totalAmount === 'Error'} // Disable Pay Now until total is fetched
        >
          {loading ? <Spinner animation="border" size="sm" /> : 'Pay Now'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default PaymentModal;
