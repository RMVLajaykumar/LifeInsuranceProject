import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';

import Header from '../layout/Header';
import Footer from '../layout/Footer';

import DashboardCard from '../../sharedComponents/DashboardCard';
import Loader from '../../sharedComponents/Loader';
import NewToast, { showToast } from '../../sharedComponents/NewToast';
import QueryModal from './CustomerQueryForm'; 

import { verifyCustomer, getProfile } from '../../services/AuthService';

const CustomerDashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [isCustomer, setIsCustomer] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [showQueryModal, setShowQueryModal] = useState(false); 

  useEffect(() => {
    const checkCustomerStatus = async () => {
      try {
        const isCustomer = await verifyCustomer();
        if (isCustomer) {
          setIsCustomer(true);
          await fetchProfileData();
        } else {
          showToast('Unauthorized Access! Please Login', 'error');
          setTimeout(() => {
            navigate('/login');
          }, 1000);
        }
      } catch (error) {
        showToast('Internal Server Error', 'error');
        setTimeout(() => {
          navigate('/login');
        }, 1000);
      } finally {
        setLoading(false);
      }
    };

    const fetchProfileData = async () => {
      try {
        const profileData = await getProfile();
        setCustomerName(profileData.name);
      } catch (error) {
        showToast('Failed to load profile', 'error');
      }
    };

    checkCustomerStatus();
  }, [navigate]);

  if (!isCustomer) {
    return null;
  }
  if (loading) {
    return <Loader />;
  }

  

  const handleGetPolicy = () => {
    navigate('/view-policy');
  };

  const handleWriteQuery = () => {
    setShowQueryModal(true); 
  };

  const handleCloseQueryModal = () => {
    setShowQueryModal(false); 
  };

  const handleAddPolicy = () => {
    navigate('/add-policy');
  };

  const handleInstallments = () => {
    navigate('/installments');
  };

  const handleTransactions = () => {
    navigate('/transactions');
  };
  const handleViewAllQueries=()=>{
    navigate('/view-queries')
  }

  return (
    <Container fluid className="d-flex flex-column min-vh-100 px-0">
      <Header />
      <Container fluid className="py-5 px-5" style={{ backgroundColor: 'rgba(230, 242, 255, 0.5)' }}>
        <Row className="px-5 mb-5">
          <Col xs={12} md={6}>
            <div className="text-center">
              <h1 className="display-4">Welcome, {customerName}!</h1>
              <p className="lead">Your dashboard for managing your profile and services.</p>
            </div>
          </Col>
        </Row>
        <Row className="px-5">
          <Col md={4}>
            <DashboardCard
              title="Add New Policy"
              text="Add a new policy"
              handleButton={handleAddPolicy}
              buttonText="Add Policy"
            />
          </Col>
          <Col md={4}>
            <DashboardCard
              title="View Policy"
              text="View and manage your policies"
              handleButton={handleGetPolicy}
              buttonText="View Policy"
            />
          </Col>
          <Col md={4}>
            <DashboardCard
              title="Write Query"
              text="Submit a query for support"
              handleButton={handleWriteQuery} 
              buttonText="Write Query"
            />
          </Col>
          <Col md={4}>
            <DashboardCard
              title="View Installments"
              text="View and pay installments"
              handleButton={handleInstallments}
              buttonText="Installments"
            />
          </Col>
          <Col md={4}>
            <DashboardCard
              title="View Transactions"
              text="See all transactions regarding policies"
              handleButton={handleTransactions}
              buttonText="Transaction Report"
            />
          </Col>
          <Col md={4}>
            <DashboardCard
              title="View All Queries"
              text="view all customers queries and responses"
              handleButton={handleViewAllQueries}
              buttonText="View All Queries"
            />
          </Col>
        </Row>
      </Container>
      <NewToast />
      <Footer />

      
      <QueryModal show={showQueryModal} handleClose={handleCloseQueryModal} />
    </Container>
  );
};

export default CustomerDashboard;
