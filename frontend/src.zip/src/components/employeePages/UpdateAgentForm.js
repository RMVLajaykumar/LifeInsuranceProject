import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Form, Button, Container } from 'react-bootstrap';
import axios from 'axios';
import { successToast, errorToast } from '../../sharedComponents/MyToast';
import { ToastContainer } from 'react-toastify';
const UpdateAgentForm = () => {
    const { agentId } = useParams();
    const [agent, setAgent] = useState({
        name: '',
        username: '',
        phoneNumber: '',
        address: '',
        city_id: '',
        commissionRate: '',
    });
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    
    useEffect(() => {
        const fetchAgent = async () => {
            try {
                const response = await axios.get(`http://localhost:8081/SecureLife.com/agents/${agentId}`, {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`
                    }
                });
                setAgent(response.data); 
                setLoading(false);
            } catch (error) {
                console.error('Error fetching agent details:', error);
            }
        };

        fetchAgent();
    }, [agentId]);

    
    const handleChange = (e) => {
        const { name, value } = e.target;
        setAgent((prevAgent) => ({ ...prevAgent, [name]: value }));
    };

   
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.put(`http://localhost:8081/SecureLife.com/agent/${agentId}`, agent, {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });
           successToast("updated Successfully")
           setTimeout(()=>{ navigate('/view-agents'); },2000)
        } catch (error) {
            console.error('Error updating agent:', error);
            errorToast("failed to update!!")
        }
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <Container className="mt-5">
            <h1>Update Agent</h1>
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="name">
                    <Form.Label>Name</Form.Label>
                    <Form.Control
                        type="text"
                        name="name"
                        value={agent.name}
                        onChange={handleChange}
                        required
                    />
                </Form.Group>

                <Form.Group controlId="username">
                    <Form.Label>Username</Form.Label>
                    <Form.Control
                        type="text"
                        name="username"
                        value={agent.username}
                        onChange={handleChange}
                        required
                    />
                </Form.Group>

                <Form.Group controlId="phoneNumber">
                    <Form.Label>Phone Number</Form.Label>
                    <Form.Control
                        type="text"
                        name="phoneNumber"
                        value={agent.phoneNumber}
                        onChange={handleChange}
                        required
                    />
                </Form.Group>

                <Form.Group controlId="address">
                    <Form.Label>Address</Form.Label>
                    <Form.Control
                        type="text"
                        name="address"
                        value={agent.address}
                        onChange={handleChange}
                        required
                    />
                </Form.Group>

                <Form.Group controlId="city_id">
                    <Form.Label>City ID</Form.Label>
                    <Form.Control
                        type="text"
                        name="city_id"
                        value={agent.city_id}
                        onChange={handleChange}
                        required
                    />
                </Form.Group>

                <Form.Group controlId="commissionRate">
                    <Form.Label>Commission Rate</Form.Label>
                    <Form.Control
                        type="number"
                        name="commissionRate"
                        value={agent.commissionRate}
                        onChange={handleChange}
                        required
                    />
                </Form.Group>

                <Button variant="primary" type="submit" className="mt-3">
                    Update Agent
                </Button>
            </Form>
            <ToastContainer/>
        </Container>
    );
};

export default UpdateAgentForm;
