import React, { useState, useEffect } from 'react';
import { Button, Container, Row, Col, Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { getProfile, verifyEmployee } from '../../services/AuthService';
import Loader from '../../sharedComponents/Loader';
import ErrorPage from '../../sharedComponents/ErrorPage';
import Header from '../layout/Header';
import Footer from '../layout/Footer';
import CommissionReportModal from './CommissionReportModal';  

const EmployeeDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [employee, setEmployee] = useState({});
  const [showModal, setShowModal] = useState(false); 
  const navigate = useNavigate();

  useEffect(() => {
    const checkEmployeeStatus = async () => {
      try {
       
        const isEmployee = await verifyEmployee();
        if (isEmployee) {
          await fetchDashboardData();
        } else {
          navigate('/unauthorized');
        }
      } catch (error) {
        console.error('Error during employee verification:', error);
        navigate('/unauthorized');
      }
    };

    const fetchDashboardData = async () => {
      try {
        const employeeData = await getProfile();
        console.log("Employee data: ", employeeData);  
        setEmployee(employeeData);
      } catch (error) {
        setError("Error fetching dashboard data");
      } finally {
        setLoading(false);
      }
    };

    checkEmployeeStatus();
  }, [navigate]);

  if (loading) {
    return <Loader />;
  }

  if (error) {
    return <ErrorPage />;
  }

  const handleAddAgent = () => navigate('/add-agent');
  const handleViewCustomers = () => navigate('/view-customers');
  const handleViewAgents = () => navigate('/view-agents');
  const handleViewQueries = () => navigate('/view-queries/employee'); 
  
  const handleViewCommissionReport = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  return (
    <Container fluid className="mt-5 d-flex flex-column">
      <Header />
      <Row className="justify-content-center">
        <Col xs={12} md={8} className="text-center">
          <h1>Employee Dashboard</h1>
          <h3>Welcome, {employee.name || "Employee"}!</h3>
        </Col>
      </Row>

      <Row className="mt-4">
        <Col xs={12} md={4}>
          <Card className="text-center">
            <Card.Body>
              <Card.Title>Add Agent</Card.Title>
              <Card.Text>Manage agents and add new ones.</Card.Text>
              <Button variant="primary" onClick={handleAddAgent}>
                Add Agent
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} md={4}>
          <Card className="text-center">
            <Card.Body>
              <Card.Title>View Customers</Card.Title>
              <Card.Text>View and manage customer information.</Card.Text>
              <Button variant="warning" onClick={handleViewCustomers}>
                View Customers
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} md={4}>
          <Card className="text-center">
            <Card.Body>
              <Card.Title>View Agents</Card.Title>
              <Card.Text>View and manage agent information.</Card.Text>
              <Button variant="info" onClick={handleViewAgents}>
                View Agents
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row className="mt-4">
        <Col xs={12} md={4}>
          <Card className="text-center">
            <Card.Body>
              <Card.Title>View Commission Report</Card.Title>
              <Card.Text>Check and manage commissions for agents.</Card.Text>
              <Button variant="success" onClick={handleViewCommissionReport}>
                View Commission Report
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} md={4}> 
          <Card className="text-center">
            <Card.Body>
              <Card.Title>View Queries</Card.Title>
              <Card.Text>Check and manage customer queries.</Card.Text>
              <Button variant="danger" onClick={handleViewQueries}>
                View Queries
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <CommissionReportModal show={showModal} handleClose={handleCloseModal} />

      <Footer />
    </Container>
  );
};

export default EmployeeDashboard;
